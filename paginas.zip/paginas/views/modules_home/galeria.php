      <!-- Portfolio Gallery -->
      <div class="g-text-center--xs g-margin-b-40--xs">
                <h2 class="g-font-size-32--xs g-font-size-36--md">Projects</h2>
      </div>
        <div class="container g-margin-b-600--xs">
            <div id="js__grid-portfolio-gallery" class="cbp">
                
              <?php 
              $galeria= new Galery();
              $galeria->seleccionarGaleryController();
               ?>
                <!-- End Item -->
            </div>
            <!-- End Portfolio Gallery -->
        </div>
        <!-- End Portfolio -->