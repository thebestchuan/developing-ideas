        <!-- Parallax -->
        <?php 
        $gestorParallax= new Parallax();
         $gestorParallax->seleccionarParallaxController();
         ?>
        <!-- End Parallax -->