<!DOCTYPE html>
<html lang="en" class="no-js">
    <!-- Begin Head -->
    <head>
        <!-- Basic -->
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Megakit - HTML5 Theme</title>
        <meta name="keywords" content="HTML5 Theme" />
        <meta name="description" content="Megakit - HTML5 Theme">
        <meta name="author" content="keenthemes.com">

        <!-- Web Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i|Montserrat:400,700" rel="stylesheet">

        <!-- Vendor Styles -->
        <link href="views/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="views/css/animate.css" rel="stylesheet" type="text/css"/>
        <link href="views/vendor/themify/themify.css" rel="stylesheet" type="text/css"/>
        <link href="views/vendor/scrollbar/scrollbar.min.css" rel="stylesheet" type="text/css"/>
        <link href="views/vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css"/>
        <link href="views/vendor/swiper/swiper.min.css" rel="stylesheet" type="text/css"/>
        <link href="views/vendor/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" type="text/css"/>

        <!-- Theme Styles -->
        <link href="views/css/style.css" rel="stylesheet" type="text/css"/>
        <link href="views/css/global/global.css" rel="stylesheet" type="text/css"/>

        <!-- Favicon -->
        <link rel="shortcut icon" href="views/img/favicon.ico" type="image/x-icon">
        <link rel="apple-touch-icon" href="views/img/apple-touch-icon.png">
        <link rel="stylesheet" href="views/css/sweetalert.css">


        <script src="views/js/sweetalert.min.js"></script>


    </head>
    <!-- End Head -->

    <!-- Body -->
    <body>

        <!--========== HEADER ==========-->
    <?php  include "modules_home/header.php";?>
        <!--========== END HEADER ==========-->

        <!--========== SWIPER SLIDER ==========-->
        <?php include "modules_home/slide.php"; ?>
        <!--========== END SWIPER SLIDER ==========-->

        <!--========== PAGE CONTENT ==========-->
        <!-- Features -->
        <?php include "modules_home/features.php"; ?>
        <!-- End Features -->

        <!-- Parallax -->
        <?php include "modules_home/parallax.php"; ?>
        <!-- End Parallax -->

        <!-- Culture -->
        <?php include "modules_home/culture.php";  ?>
        <!-- End Culture -->

        <!-- Portfolio Gallery -->
        <?php  include"modules_home/galeria.php"; ?>
        <!-- End Portfolio -->

        <!-- News -->
        <?php include "modules_home/noticias.php"; ?>
        <!-- End News -->

        <!-- Feedback Form -->
       <?php  include "modules_home/mensajeria.php"; ?>
        <!-- End Feedback Form -->

        <!-- Google Map -->
      <?php include "modules_home/google.php"; ?>
        <!-- End Google Map -->
        <!--========== END PAGE CONTENT ==========-->

        <!--========== FOOTER ==========-->
        <?php include "modules_home/footer.php"; ?>
        <!--========== END FOOTER ==========-->

        <!-- Back To Top -->
        <?php include"modules_home/top.php"; ?>

        <!--========== JAVASCRIPTS (Load javascripts at bottom, this will reduce page load time) ==========-->
        <!-- Vendor -->
        <script type="text/javascript" src="views/vendor/jquery.min.js"></script>
        <script type="text/javascript" src="views/vendor/jquery.migrate.min.js"></script>
        <script type="text/javascript" src="views/vendor/bootstrap/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="views/vendor/jquery.smooth-scroll.min.js"></script>
        <script type="text/javascript" src="views/vendor/jquery.back-to-top.min.js"></script>
        <script type="text/javascript" src="views/vendor/scrollbar/jquery.scrollbar.min.js"></script>
        <script type="text/javascript" src="views/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
        <script type="text/javascript" src="views/vendor/swiper/swiper.jquery.min.js"></script>
        <script type="text/javascript" src="views/vendor/waypoint.min.js"></script>
        <script type="text/javascript" src="views/vendor/counterup.min.js"></script>
        <script type="text/javascript" src="views/vendor/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
        <script type="text/javascript" src="views/vendor/jquery.parallax.min.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBsXUGTFS09pLVdsYEE9YrO2y4IAncAO2U"></script>
        <script type="text/javascript" src="vendor/jquery.wow.min.js"></script>

        <!-- General Components and Settings -->
        <script type="text/javascript" src="views/js/global.min.js"></script>
        <script type="text/javascript" src="views/js/components/header-sticky.min.js"></script>
        <script type="text/javascript" src="views/js/components/scrollbar.min.js"></script>
        <script type="text/javascript" src="views/js/components/magnific-popup.min.js"></script>
        <script type="text/javascript" src="views/js/components/swiper.min.js"></script>
        <script type="text/javascript" src="views/js/components/counter.min.js"></script>
        <script type="text/javascript" src="views/js/components/portfolio-3-col.min.js"></script>
        <script type="text/javascript" src="views/js/components/parallax.min.js"></script>
        <script type="text/javascript" src="views/js/components/google-map.min.js"></script>
        <script type="text/javascript" src="views/js/components/wow.min.js"></script>
        <script type="text/javascript" src="views/js/gestorMensajes.js"></script>
        <!--========== END JAVASCRIPTS ==========-->

    </body>
    <!-- End Body -->
</html>
