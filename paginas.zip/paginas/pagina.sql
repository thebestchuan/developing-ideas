-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-01-2018 a las 17:07:07
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pagina`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

CREATE TABLE `articulos` (
  `id` int(11) NOT NULL,
  `titulo` text NOT NULL,
  `introduccion` text NOT NULL,
  `ruta` text NOT NULL,
  `contenido` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `articulos`
--

INSERT INTO `articulos` (`id`, `titulo`, `introduccion`, `ruta`, `contenido`) VALUES
(1, 'Now That Your Brand Is All Dressed Up And Ready To Party,', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party...', 'views/images/articulos/articulo276.jpg', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,'),
(2, 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,', 'Now That Your Brand Is All Dressed Up And Ready To Party,...', 'views/images/articulos/articulo959.jpg', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,'),
(3, 'Now That Your Brand Is All Dressed Up And Ready To Party,', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party...', 'views/images/articulos/articulo912.jpg', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,'),
(4, 'Now That Your Brand Is All Dressed Up And Ready To Party,', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party...', 'views/images/articulos/articulo931.jpg', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,'),
(5, 'Now That Your Brand Is All Dressed Up And Ready To Party,', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party...', 'views/images/articulos/articulo708.jpg', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,'),
(6, 'Now That Your Brand Is All Dressed Up And Ready To Party,', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party...', 'views/images/articulos/articulo417.jpg', 'Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,Now That Your Brand Is All Dressed Up And Ready To Party,');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `culture`
--

CREATE TABLE `culture` (
  `id` int(11) NOT NULL,
  `titulo` text NOT NULL,
  `subtitulo` text NOT NULL,
  `ruta` text NOT NULL,
  `subtitulo1` text NOT NULL,
  `contenido` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `culture`
--

INSERT INTO `culture` (`id`, `titulo`, `subtitulo`, `ruta`, `subtitulo1`, `contenido`) VALUES
(4, 'culture 1', 'about 1', 'views/images/culture/articulo210.jpg', 'megakit 1', 'We aim high at being focused on building relationships with our clients and community. Using our creative gifts drives this foundation. The time has come to bring those ideas and plans to life. This is where we really begin to visualize your napkin sketches and make them into beautiful pixels.\r\n\r\nNow that your brand is all dressed up and ready to party, it\'s time to release it to the world. By the way, let\'s celebrate already.We aim high at being focused on building relationships with our clients and community. Using our creative gifts drives this foundation. The time has come to bring those ideas and plans to life. This is where we really begin to visualize your napkin sketches and make them into beautiful pixels.\r\n\r\nNow that your brand is all dressed up and ready to party, it\'s time to release it to the world. By the way, let\'s celebrate already.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `galeria`
--

CREATE TABLE `galeria` (
  `id` int(11) NOT NULL,
  `ruta` text NOT NULL,
  `titulo` text NOT NULL,
  `descripcion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `galeria`
--

INSERT INTO `galeria` (`id`, `ruta`, `titulo`, `descripcion`) VALUES
(12, '../../views/images/galeria/imageOld198.jpg', 'Tally', 'Argerinne'),
(13, '../../views/images/galeria/imageOld527.jpg', '', ''),
(14, '../../views/images/galeria/imageOld239.jpg', '', ''),
(15, '../../views/images/galeria/imageOld258.jpg', '', ''),
(17, '../../views/images/galeria/imageOld780.jpg', '', ''),
(18, '../../views/images/galeria/imageOld353.jpg', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `id` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `email` text NOT NULL,
  `telefono` int(15) NOT NULL,
  `mensaje` text NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `revision` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id`, `nombre`, `email`, `telefono`, `mensaje`, `fecha`, `revision`) VALUES
(14, 'again', 'chuancito@live.com', 98765432, 'cuANDO ME ', '2018-01-07 20:44:23', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE `noticias` (
  `id` int(11) NOT NULL,
  `titulo` text NOT NULL,
  `subtitulo` text NOT NULL,
  `ruta` text NOT NULL,
  `contenido` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `noticias`
--

INSERT INTO `noticias` (`id`, `titulo`, `subtitulo`, `ruta`, `contenido`) VALUES
(3, 'Noticia 5', 'Noticia numero 5', 'views/images/noticias/noticiaNew125.jpg', 'Noticia numero 5'),
(4, 'Noticia 1', 'Noticia 1', 'views/images/noticias/noticiaOld394.jpg', 'Noticia 1 Noticia 1'),
(5, 'Noticia 2', 'Noticia 2', 'views/images/noticias/noticiaOld564.jpg', 'Noticia 1 Noticia 1 Noticia 1 v Noticia 1'),
(6, 'Noticia 3', 'Noticia 3', 'views/images/noticias/noticiaOld535.jpg', 'Noticia 3 Noticia 3 Noticia 3 Noticia 3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parallax`
--

CREATE TABLE `parallax` (
  `id` int(11) NOT NULL,
  `titulo` text NOT NULL,
  `ruta` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `parallax`
--

INSERT INTO `parallax` (`id`, `titulo`, `ruta`) VALUES
(5, 'The Fastest Way To Develop', 'views/images/parallax/Parallaxnew478.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `slide`
--

CREATE TABLE `slide` (
  `id` int(11) NOT NULL,
  `titulo` text NOT NULL,
  `ruta` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `slide`
--

INSERT INTO `slide` (`id`, `titulo`, `ruta`) VALUES
(10, 'Chamaco', 'views/images/slide/slid346.jpg'),
(11, 'hola', 'views/images/slide/slid292.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `suscriptores`
--

CREATE TABLE `suscriptores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `revision` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `suscriptores`
--

INSERT INTO `suscriptores` (`id`, `nombre`, `email`, `revision`) VALUES
(5, 'Antero ', 'abueno@hotmail.com', 1),
(6, 'yo', 'yommm@live.com', 1),
(7, 'hope', 'chuan@live.com', 1),
(8, 'again', 'again@live.com', 1),
(9, 'again', 'chuancito@live.com', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `usuario` varchar(10) NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `photo` text NOT NULL,
  `rol` int(11) NOT NULL,
  `intentos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `usuario`, `password`, `email`, `photo`, `rol`, `intentos`) VALUES
(7, 'admin', '$2a$07$asxx54ahjppf45sd87a5aunxs9bkpyGmGE/.vekdjFg83yRec789S', 'antero@hotmail.com', 'views/images/perfiles/perfil506.jpg', 0, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `culture`
--
ALTER TABLE `culture`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `galeria`
--
ALTER TABLE `galeria`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `parallax`
--
ALTER TABLE `parallax`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `suscriptores`
--
ALTER TABLE `suscriptores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `articulos`
--
ALTER TABLE `articulos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `culture`
--
ALTER TABLE `culture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `galeria`
--
ALTER TABLE `galeria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de la tabla `noticias`
--
ALTER TABLE `noticias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `parallax`
--
ALTER TABLE `parallax`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT de la tabla `suscriptores`
--
ALTER TABLE `suscriptores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
