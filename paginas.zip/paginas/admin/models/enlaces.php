<?php

class EnlacesModels{

	public function enlacesModel($enlaces){

		if($enlaces == "inicio" ||
		   $enlaces == "login" ||
		   $enlaces == "slide" ||
		   $enlaces == "articulos" ||
		   $enlaces == "galeria" ||
		   $enlaces == "culture" ||
		   $enlaces == "noticias" ||
		   $enlaces == "parallax" ||
		   $enlaces == "suscriptores" ||
		   $enlaces == "mensajes" ||
		   $enlaces == "perfil" ||
		   $enlaces == "salir"){

			$module = "views/paginas/".$enlaces.".php";
		}	

		else if($enlaces == "index"){
			$module = "views/paginas/login.php";
		}

		else{
			$module = "views/paginas/login.php";		
		}

		return $module;

	}


}