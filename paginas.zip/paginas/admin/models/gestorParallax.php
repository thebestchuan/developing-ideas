<?php
require_once "conexion.php";

class GestorParallaxModel{

	#GUARDAR Slide
	#------------------------------------------------------------

	public function guardarParallaxModel($datosModel, $tabla){

		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla (titulo, ruta ) VALUES (:titulo, :ruta)");

		$stmt -> bindParam(":titulo", $datosModel["titulo"], PDO::PARAM_STR);		
		$stmt -> bindParam(":ruta", $datosModel["ruta"], PDO::PARAM_STR);		

		if($stmt->execute()){

			return "ok";
		}

		else{

			return "error";
		}

		$stmt->close();

	}

	// #MOSTRAR Slide
	// #------------------------------------------------------
	public function mostrarParallaxModel($tabla){

		$stmt = Conexion::conectar()->prepare("SELECT id, titulo, ruta FROM $tabla");

		$stmt -> execute();

		return $stmt -> fetchAll();

		$stmt -> close();

	}

	// #BORRAR ARTICULOS
	// #-----------------------------------------------------
	public function borrarParallaxModel($datosModel, $tabla){

		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");

		$stmt->bindParam(":id", $datosModel, PDO::PARAM_INT);

		if($stmt->execute()){

			return "ok";

		}

		else{

			return "error";

		}

		$stmt->close();

	}

	// #ACTUALIZAR ARTICULOS
	// #---------------------------------------------------
	public function editarParallaxModel($datosModel, $tabla){

		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET titulo = :titulo, ruta = :ruta WHERE id = :id");	

		$stmt -> bindParam(":titulo", $datosModel["titulo"], PDO::PARAM_STR);		
		$stmt -> bindParam(":ruta", $datosModel["ruta"], PDO::PARAM_STR);		
		$stmt -> bindParam(":id", $datosModel["id"], PDO::PARAM_INT);

		if($stmt->execute()){

			return "ok";
		}

		else{

			return "error";
		}

		$stmt->close();

	}

}