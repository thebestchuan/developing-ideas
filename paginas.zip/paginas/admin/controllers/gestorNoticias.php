<?php

class gestorNoticias{

	#MOSTRAR IMAGEN NOTICIA
	#------------------------------------------------------------
	public function mostrarImagenController($datos){

		list($ancho, $alto) = getimagesize($datos);

		if($ancho < 970 || $alto < 970){

			echo 0;

		}

		else{

			$aleatorio = mt_rand(100, 999);
			$ruta = "../../views/images/noticias/temp/noticiaOld".$aleatorio.".jpg";
			$origen = imagecreatefromjpeg($datos);
			$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>970, "height"=>970]);
			imagejpeg($destino, $ruta);

			echo $ruta;
		}

	}

	#GUARDAR Noticia
	#-----------------------------------------------------------

	public function guardarNoticiaController(){

		if(isset($_POST["tituloNoticia"])){

			$imagen = $_FILES["imagen"]["tmp_name"];

			$borrar = glob("views/images/noticias/temp/*");

			foreach($borrar as $file){

				unlink($file);

			}

			$aleatorio = mt_rand(100, 999);

			$ruta = "views/images/noticias/noticiaOld".$aleatorio.".jpg";

			$origen = imagecreatefromjpeg($imagen);

			$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>970, "height"=>970]);

			imagejpeg($destino, $ruta);

			$datosController = array("titulo"=>$_POST["tituloNoticia"],
				                     "subtitulo"=>$_POST["subtituloNoticia"],
			 	                      "ruta"=>$ruta,
			 	                      "contenido"=>$_POST["contenidoNoticia"]);

			$respuesta = GestorNoticiasModel::guardarNoticiaModel($datosController, "noticias");

			if($respuesta == "ok"){

				echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Creado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "noticias";
							  } 
					});


				</script>';

			}

			else{

				echo $respuesta;

			}

		}

	}

	#MOSTRAR NOTICIAS
	#-----------------------------------------------------------

	public function mostrarNoticiasController(){

		$respuesta = GestorNoticiasModel::mostrarNoticiasModel("noticias");		

		foreach($respuesta as $row => $item) {

		echo '<div class="col-md-4" style="border: dashed; padding: 10px;" id="'.$item["id"].'">
   <span class="handleArticle" style="position:absolute">
   <a href="index.php?action=noticias&idBorrar='.$item["id"].'&rutaImagen='.$item["ruta"].'">
   <i class="fa fa-times btn btn-danger"></i>
	</a>
   <i class="fa fa-pencil btn btn-primary editarNoticia"></i>	
   </span>
   <img src="'.$item["ruta"].'" class="img-thumbnail">
   <h1>'.$item["titulo"].'</h1>
   <p>'.$item["subtitulo"].'</p>
   <p>'.$item["contenido"].'</p>
</div>';

		}

	}

	#BORRAR NOTICIA
	#------------------------------------

	public function borrarNoticiasController(){

		if(isset($_GET["idBorrar"])){

			unlink($_GET["rutaImagen"]);

			$datosController = $_GET["idBorrar"];

			$respuesta = GestorArticulosModel::borrarArticuloModel($datosController, "noticias");

			if($respuesta == "ok"){

					echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Borrado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "noticias";
							  } 
					});


				</script>';

			}
		}

	}

	#ACTUALIZAR NOTICIA
	#-----------------------------------------------------------

	public function editarNoticiasController(){

		$ruta = "";

		if(isset($_POST["editarTitulo"])){

			if(isset($_FILES["editarImagen"]["tmp_name"])){	

				$imagen = $_FILES["editarImagen"]["tmp_name"];

				$aleatorio = mt_rand(100, 999);

				$ruta = "views/images/noticias/noticiaNew".$aleatorio.".jpg";

				$origen = imagecreatefromjpeg($imagen);

				$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>970, "height"=>970]);

				imagejpeg($destino, $ruta);

				$borrar = glob("views/images/noticias/temp/*");

				foreach($borrar as $file){
				
					unlink($file);
				
				}

			}

			if($ruta == ""){

				$ruta = $_POST["fotoAntigua"];

			}

			else{

				unlink($_POST["fotoAntigua"]);

			}

			$datosController = array("id"=>$_POST["id"],
			                         "titulo"=>$_POST["editarTitulo"],
								     "subtitulo"=>$_POST["editarSubtitulo"],
								     "ruta"=>$ruta,
								     "contenido"=>$_POST["editarContenido"]);

			$respuesta = GestorNoticiasModel::editarNoticiaModel($datosController, "noticias");

			if($respuesta == "ok"){

				echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Actualizado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "noticias";
							  } 
					});


				</script>';

			}

			else{

				echo $respuesta;

			}

		}

	}
	
}