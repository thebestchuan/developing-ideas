<?php

class GestorSlide{

	#MOSTRAR IMAGEN Slide
	#------------------------------------------------------------
	public function mostrarImagenController($datos){

		list($ancho, $alto) = getimagesize($datos);

		if($ancho < 1920 || $alto < 1080){

			echo 0;

		}

		else{

			$aleatorio = mt_rand(100, 999);
			$ruta = "../../views/images/slide/temp/slid".$aleatorio.".jpg";
			$origen = imagecreatefromjpeg($datos);
			$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>1920, "height"=>1080]);
			imagejpeg($destino, $ruta);

			echo $ruta;
		}

	}

	#GUARDAR Slide
	#-----------------------------------------------------------

	public function guardarSlideController(){

		if(isset($_POST["tituloSlide"])){

			$imagen = $_FILES["imagen"]["tmp_name"];

			$borrar = glob("views/images/slide/temp/*");

			foreach($borrar as $file){

				unlink($file);

			}

			$aleatorio = mt_rand(100, 999);

			$ruta = "views/images/slide/slid".$aleatorio.".jpg";

			$origen = imagecreatefromjpeg($imagen);

			$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>1920, "height"=>1080]);

			imagejpeg($destino, $ruta);

			$datosController = array("titulo"=>$_POST["tituloSlide"],				                     
			 	                      "ruta"=>$ruta);

			$respuesta = GestorSlideModel::guardarSlideModel($datosController, "slide");

			if($respuesta == "ok"){

				echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Imgen Subido correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "slide";
							  } 
					});


				</script>';

			}

			else{

				echo $respuesta;

			}

		}

	}



	// #MOSTRAR ARTICULOS
	// #-----------------------------------------------------------

	public function mostrarSlideController(){

		$respuesta = GestorSlideModel::mostrarSlideModel("slide");		

		foreach($respuesta as $item) {

			echo '<div class="col-md-4" style="padding: 15px; border: dashed;" id="'.$item["id"].'">
		<span class="handleArticle">
					<a href="index.php?action=slide&idBorrar='.$item["id"].'&rutaImagen='.$item["ruta"].'">
						<i class="fa fa-times btn btn-danger pull-right"></i>
					</a>
					<i class="fa fa-pencil btn btn-primary editarSlide  pull-right"></i>	
					</span>		
			<img src="'.$item["ruta"].'" class="img-thumbnail">
					<h1>'.$item["titulo"].'</h1>
			<hr>
		</div>';

		}

	}

	// #BORRAR ARTICULO
	// #------------------------------------

	public function borrarSlideController(){

		if(isset($_GET["idBorrar"])){

			unlink($_GET["rutaImagen"]);

			$datosController = $_GET["idBorrar"];

			$respuesta = GestorSlideModel::borrarSlideModel($datosController, "slide");

			if($respuesta == "ok"){

					echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Imagen Borrado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "slide";
							  } 
					});


				</script>';

			}
		}

	}

	// #ACTUALIZAR ARTICULO
	// #-----------------------------------------------------------

	public function editarSlideController(){

		$ruta = "";

		if(isset($_POST["editarTitulo"])){

			if(isset($_FILES["editarImagen"]["tmp_name"])){	

				$imagen = $_FILES["editarImagen"]["tmp_name"];

				$aleatorio = mt_rand(100, 999);

				$ruta = "views/images/slide/slidnew".$aleatorio.".jpg";

				$origen = imagecreatefromjpeg($imagen);

				$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>1920, "height"=>1080]);

				imagejpeg($destino, $ruta);

				$borrar = glob("views/images/slide/temp/*");

				foreach($borrar as $file){
				
					unlink($file);
				
				}

			}

			if($ruta == ""){

				$ruta = $_POST["fotoAntigua"];

			}

			else{

				unlink($_POST["fotoAntigua"]);

			}

			$datosController = array("id"=>$_POST["id"],
			                         "titulo"=>$_POST["editarTitulo"],								    
								     "ruta"=>$ruta
								    );

			$respuesta = GestorSlideModel::editarSlideModel($datosController, "slide");

			if($respuesta == "ok"){

				echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Imgen actualizado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "slide";
							  } 
					});


				</script>';

			}

			else{

				echo $respuesta;

			}

		}

	}
	
}