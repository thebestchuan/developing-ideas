<?php

class GestorCulture{

	#MOSTRAR IMAGEN ARTÍCULO
	#------------------------------------------------------------
	public function mostrarImagenController($datos){

		list($ancho, $alto) = getimagesize($datos);

		if($ancho < 970 || $alto < 970){
			echo 0;
		}

		else{
			$aleatorio = mt_rand(100, 999);
			$ruta = "../../views/images/culture/temp/culture".$aleatorio.".jpg";
			$origen = imagecreatefromjpeg($datos);
			$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>970, "height"=>970]);
			imagejpeg($destino, $ruta);

			echo $ruta;
		}

	}

	#GUARDAR ARTICULO
	#-----------------------------------------------------------

	public function guardarCultureController(){

		if(isset($_POST["tituloCulture"])){

			$imagen = $_FILES["imagen"]["tmp_name"];

			$borrar = glob("views/images/culture/temp/*");

			foreach($borrar as $file){

				unlink($file);

			}

			$aleatorio = mt_rand(100, 999);

			$ruta = "views/images/culture/articulo".$aleatorio.".jpg";

			$origen = imagecreatefromjpeg($imagen);

			$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>970, "height"=>970]);

			imagejpeg($destino, $ruta);

			$datosController = array("titulo"=>$_POST["tituloCulture"],
				                      "subtitulo"=>$_POST["subtituloCulture"],
			 	                      "ruta"=>$ruta,
			 	                      "subtitulo1"=>$_POST["subtituloCulture1"],
			 						  "contenido"=>$_POST["contenidoCulture"]);

			$respuesta = GestorCultureModel::guardarCultureModel($datosController, "culture");

			if($respuesta == "ok"){

				echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Creado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "culture";
							  } 
					});


				</script>';

			}

			else{

				echo $respuesta;

			}

		}

	}

	#MOSTRAR ARTICULOS
	#-----------------------------------------------------------

	public function mostrarCultureController(){

		$respuesta = GestorCultureModel::mostrarCultureModel("culture");		

		foreach($respuesta as $row => $item) {

		echo '<div class="col-md-4" style="border: dashed; padding: 10px;" id="'.$item["id"].'">
   <span class="handleArticle pull-right">
   <a href="index.php?action=culture&idBorrar='.$item["id"].'&rutaImagen='.$item["ruta"].'">
   <i class="fa fa-times btn btn-danger"></i>
	</a>
   <i class="fa fa-pencil btn btn-primary editarCulture"></i>	
   </span>
   <img src="'.$item["ruta"].'" class="img-thumbnail" height="150px">
   <h1>'.$item["titulo"].'</h1>
   <h3>'.$item["subtitulo"].'</h3>
   <h5>'.$item["subtitulo1"].'</h5>
   <p>'.$item["contenido"].'</p>
<hr>
</div>';

		}

	}

	#BORRAR ARTICULO
	#------------------------------------

	public function borrarCultureController(){

		if(isset($_GET["idBorrar"])){

			unlink($_GET["rutaImagen"]);

			$datosController = $_GET["idBorrar"];

			$respuesta = GestorCultureModel::borrarCultureModel($datosController, "culture");

			if($respuesta == "ok"){

					echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡El artículo se ha borrado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "culture";
							  } 
					});


				</script>';

			}
		}

	}

	#ACTUALIZAR ARTICULO
	#-----------------------------------------------------------

	public function editarCultureController(){

		$ruta = "";

		if(isset($_POST["editarTitulo"])){

			if(isset($_FILES["editarImagen"]["tmp_name"])){	

				$imagen = $_FILES["editarImagen"]["tmp_name"];

				$aleatorio = mt_rand(100, 999);

				$ruta = "views/images/culture/culturenew".$aleatorio.".jpg";

				$origen = imagecreatefromjpeg($imagen);

				$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>970, "height"=>970]);

				imagejpeg($destino, $ruta);

				$borrar = glob("views/images/culture/temp/*");

				foreach($borrar as $file){
				
					unlink($file);
				
				}

			}

			if($ruta == ""){

				$ruta = $_POST["fotoAntigua"];

			}

			else{

				unlink($_POST["fotoAntigua"]);

			}

			$datosController = array("id"=>$_POST["id"],
			                         "titulo"=>$_POST["editarTitulo"],
								     "subtitulo"=>$_POST["editarSubtitulo"],
								     "ruta"=>$ruta,
								     "subtitulo1"=>$_POST["editarSubtitulo1"],
								 	 "contenido"=>$_POST["editarContenido"]);

			$respuesta = GestorCultureModel::editarCultureModel($datosController, "culture");

			if($respuesta == "ok"){

				echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Actualizado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "culture";
							  } 
					});


				</script>';

			}

			else{

				echo $respuesta;

			}

		}

	}
	
}