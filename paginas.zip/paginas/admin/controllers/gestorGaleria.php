<?php

class GestorGalery{

	#MOSTRAR IMAGEN SLIDE AJAX
	#------------------------------------------------------------

	public function mostrarImageController($datos){

		#getimagesize - Obtiene el tamaño de una imagen

		#LIST(): Al igual que array(), no es realmente una función, es un constructor del lenguaje. list() se utiliza para asignar una lista de variables en una sola operación.

		list($ancho, $alto) = getimagesize($datos["imagenTemporal"]);
		
		if($ancho < 970 || $alto < 647){

			echo 0;

		}

		else{

			$aleatorio = mt_rand(100, 999);

			$ruta = "../../views/images/galeria/imageOld".$aleatorio.".jpg";

			#imagecreatefromjpeg — Crea una nueva imagen a partir de un fichero o de una URL

			$origen = imagecreatefromjpeg($datos["imagenTemporal"]);

			#imagecrop() — Recorta una imagen usando las coordenadas, el tamaño, x, y, ancho y alto dados

			$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>970, "height"=>647]);

			#imagejpeg() — Exportar la imagen al navegador o a un fichero

			imagejpeg($destino, $ruta);

			GestorGaleryModel::subirImageGaleriaModel($ruta, "galeria");

			$respuesta = GestorGaleryModel::mostrarImageGaleriaModel($ruta, "galeria");

			$enviarDatos = array("ruta"=>$respuesta["ruta"],
				                 "titulo"=>$respuesta["titulo"],
				                 "descripcion"=>$respuesta["descripcion"]);

			echo json_encode($enviarDatos);
		}

	}

	#MOSTRAR IMAGENES EN LA VISTA
	#------------------------------------------------------------

	public function mostrarImageVistaController(){

		$respuesta = GestorGaleryModel::mostrarImageVistaModel("galeria");

		foreach($respuesta as $row => $item){
	echo '<div id="'.$item["id"].'"  class="col-md-4" style="padding: 10px">
	<span style="position: absolute" class="fa fa-times btn btn-danger eliminarGaleria" ruta="'.$item["ruta"].'"></span><img src="'.substr($item["ruta"],6).'" class="handleImg" width="100%">
			</div>';
		}

	}

// 	#MOSTRAR IMAGENES EN EL EDITOR
// 	#------------------------------------------------------------

	public function editorGaleryController(){

		$respuesta = GestorGaleryModel::mostrarImageVistaModel("galeria");

		foreach($respuesta as $row => $item){

	echo '<div class="col-md-4" style="padding: 10px; border: dashed;" id="item'.$item["id"].'">
			<span class="fa fa-pencil btn btn-primary editarGalery" style="background:blue; position: absolute;"></span>
			<img src="'.substr($item["ruta"], 6).'" style="float:left; margin-bottom:10px" width="100%" class="img-thumbnail">
			<h1>'.$item["titulo"].'</h1>
			<p>'.$item["descripcion"].'</p>
			</div>';

		}

	}

// 	#ELIMINAR ITEM DEL SLIDE
// 	#-----------------------------------------------------------
	public function eliminarGaleryController($datos){

		$respuesta = GestorGaleryModel::eliminarGaleryModel($datos, "galeria");

		unlink($datos["rutaGalery"]);

		echo $respuesta;

	}

// 	#ACTUALIZAR ITEM DEL SLIDE
// 	#-----------------------------------------------------------

	public function actualizarGaleryController($datos){

		GestorGaleryModel::actualizarGaleryModel($datos, "galeria");
		$respuesta = GestorGaleryModel::seleccionarActualizacionGaleryModel($datos, "galeria");

		$enviarDatos = array("titulo"=>$respuesta["titulo"],
			                 "descripcion"=>$respuesta["descripcion"]);
		
		echo json_encode($enviarDatos);
	}

}