<?php

class GestorParallax{

	#MOSTRAR IMAGEN Slide
	#------------------------------------------------------------
	public function mostrarImagenController($datos){

		list($ancho, $alto) = getimagesize($datos);

		if($ancho < 1920 || $alto < 1080){

			echo 0;

		}

		else{

			$aleatorio = mt_rand(100, 999);
			$ruta = "../../views/images/parallax/temp/slid".$aleatorio.".jpg";
			$origen = imagecreatefromjpeg($datos);
			$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>1920, "height"=>1080]);
			imagejpeg($destino, $ruta);

			echo $ruta;
		}

	}

	#GUARDAR PARALLAX
	#-----------------------------------------------------------

	public function guardarParallaxController(){

		if(isset($_POST["tituloParallax"])){

			$imagen = $_FILES["imagen"]["tmp_name"];

			$borrar = glob("views/images/parallax/temp/*");

			foreach($borrar as $file){

				unlink($file);

			}

			$aleatorio = mt_rand(100, 999);

			$ruta = "views/images/parallax/slid".$aleatorio.".jpg";

			$origen = imagecreatefromjpeg($imagen);

			$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>1920, "height"=>1080]);

			imagejpeg($destino, $ruta);

			$datosController = array("titulo"=>$_POST["tituloParallax"],				                     
			 	                      "ruta"=>$ruta);

			$respuesta = GestorParallaxModel::guardarParallaxModel($datosController, "parallax");

			if($respuesta == "ok"){

				echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Imagen Subido correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "parallax";
							  } 
					});


				</script>';

			}

			else{

				echo $respuesta;

			}

		}

	}



	// #MOSTRAR PARALLAX
	// #-----------------------------------------------------------

	public function mostrarParallaxController(){

		$respuesta = GestorSlideModel::mostrarSlideModel("parallax");		

		foreach($respuesta as $item) {

			echo '<div class="col-md-4 paralax " style="padding: 15px; border: dashed;" id="'.$item["id"].'">
		<span class="handleArticle">
					<a href="index.php?action=parallax&idBorrar='.$item["id"].'&rutaImagen='.$item["ruta"].'">
						<i class="fa fa-times btn btn-danger pull-right"></i>
					</a>
					<i class="fa fa-pencil btn btn-primary editarSlide  pull-right"></i>	
					</span>		
			<img src="'.$item["ruta"].'" class="img-thumbnail">
					<h1>'.$item["titulo"].'</h1>
			<hr>
		</div>';

		}

	}

	// #BORRAR PARALLAX
	// #------------------------------------

	public function borrarParallaxController(){

		if(isset($_GET["idBorrar"])){

			unlink($_GET["rutaImagen"]);

			$datosController = $_GET["idBorrar"];

			$respuesta = GestorSlideModel::borrarSlideModel($datosController, "parallax");

			if($respuesta == "ok"){

					echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Imagen Borrado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "parallax";
							  } 
					});


				</script>';

			}
		}

	}

	// // #ACTUALIZAR PARALLAX
	// // #-----------------------------------------------------------

	public function editarParallaxController(){

		$ruta = "";

		if(isset($_POST["editarTitulo"])){

			if(isset($_FILES["editarImagen"]["tmp_name"])){	

				$imagen = $_FILES["editarImagen"]["tmp_name"];

				$aleatorio = mt_rand(100, 999);

				$ruta = "views/images/parallax/Parallaxnew".$aleatorio.".jpg";

				$origen = imagecreatefromjpeg($imagen);

				$destino = imagecrop($origen, ["x"=>0, "y"=>0, "width"=>1920, "height"=>1080]);

				imagejpeg($destino, $ruta);

				$borrar = glob("views/images/parallax/temp/*");

				foreach($borrar as $file){
				
					unlink($file);
				
				}

			}

			if($ruta == ""){

				$ruta = $_POST["fotoAntigua"];

			}

			else{

				unlink($_POST["fotoAntigua"]);

			}

			$datosController = array("id"=>$_POST["id"],
			                         "titulo"=>$_POST["editarTitulo"],								    
								     "ruta"=>$ruta
								    );

			$respuesta = GestorSlideModel::editarSlideModel($datosController, "parallax");

			if($respuesta == "ok"){

				echo'<script>

					swal({
						  title: "¡OK!",
						  text: "¡Imgen actualizado correctamente!",
						  type: "success",
						  confirmButtonText: "Cerrar",
						  closeOnConfirm: false
					},

					function(isConfirm){
							 if (isConfirm) {	   
							    window.location = "parallax";
							  } 
					});


				</script>';

			}

			else{

				echo $respuesta;

			}

		}

	}	
	
}