<?php 
require_once "models/enlaces.php";
require_once "models/ingreso.php";
require_once "models/gestorSlide.php";
require_once "models/gestorParallax.php";
require_once "models/gestorArticulos.php";
require_once "models/gestorCulture.php";
require_once "models/gestorGaleria.php";
require_once "models/gestorNoticias.php";
require_once "models/gestorMensajes.php";
require_once "models/gestorPerfiles.php";
require_once "models/gestorSuscriptores.php";

require_once "controllers/enlaces.php";
require_once "controllers/template.php";
require_once "controllers/ingreso.php";
require_once "controllers/gestorSlide.php";
require_once "controllers/gestorParallax.php";
require_once "controllers/gestorArticulos.php";
require_once "controllers/gestorCulture.php";
require_once "controllers/gestorGaleria.php";
require_once "controllers/gestorNoticias.php";
require_once "controllers/gestorMensajes.php";
require_once "controllers/gestorPerfiles.php";
require_once "controllers/gestorSuscriptores.php";


$template = new TemplateController();
$template -> template();
