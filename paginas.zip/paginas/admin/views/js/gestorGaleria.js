/*=============================================
Área de arrastre de imágenes
=============================================*/

if($("#columnasGaleria").html() == 0){

	$("#columnasGaleria").css({"height":"100px"});

}

else{

	$("#columnasGaleria").css({"height":"auto"});

}

/*=====  Área de arrastre de imágenes  ======*/

/*=============================================
Subir Imagen
=============================================*/

$("#columnasGaleria").on("dragover", function(e){

	e.preventDefault();
	e.stopPropagation();

	$("#columnasGaleria").css({"background":"url(views/images/pattern.jpg)"})

})

/*=====  Subir Imagen  ======*/
/*=============================================
Soltar Imagen
=============================================*/

$("#columnasGaleria").on("drop", function(e){

	e.preventDefault();
	e.stopPropagation();

	$("#columnasGaleria").css({"background":"white"})

	var archivo = e.originalEvent.dataTransfer.files;
	var imagen = archivo[0];

	// Validar tamaño de la imagen
	var imagenSize = imagen.size;
	
	if(Number(imagenSize) > 2000000){

		$("#columnasGaleria").before('<div class="alert alert-warning alerta text-center">El archivo excede el peso permitido, 200kb</div>')

	}

	else{

		$(".alerta").remove();

	}

	// Validar tipo de la imagen
	var imagenType = imagen.type;
	
	if(imagenType == "image/jpeg" || imagenType == "image/png"){

		$(".alerta").remove();

	}

	else{

		$("#columnasGaleria").before('<div class="alert alert-warning alerta text-center">El archivo debe ser formato JPG o PNG</div>')

	}

	//Subir imagen al servidor
	if(Number(imagenSize) < 2000000 && imagenType == "image/jpeg" || imagenType == "image/png"){

		var datos = new FormData();

		datos.append("imagen", imagen);

		$.ajax({
			url:"views/ajax/gestorGaleria.php",
			method: "POST",
			data: datos,
			cache: false,
			contentType: false,
			processData: false,
			dataType:"json",
			beforeSend: function(){

				$("#columnasGaleria").before('<img src="views/images/status.gif" id="status">');

			},
			success: function(respuesta){

				$("#status").remove();
				
				if(respuesta == 0){

					$("#columnasGaleria").before('<div class="alert alert-warning alerta text-center">La imagen es inferior a 1600px * 600px</div>')
				
				}

				else{

					$("#columnasGaleria").css({"height":"auto"});

					$("#columnasGaleria").append('<div class="col-md-4 bloqueGalery" style="padding: 10px"><span class="fa fa-trash btn btn-danger" style="position: absolute;"></span><img src="'+respuesta["ruta"].slice(6)+'" class="handleImg" width="100%"></div>');

					$("#ordenarTextGalery").append('<div class="col-md-4" style="padding: 10px; border: dashed;"><span class="fa fa-pencil btn btn-primary" style="background:blue; position: absolute;"></span><img src="'+respuesta["ruta"].slice(6)+'" style="float:left; margin-bottom:10px" width="100%" class="img-thumbnail"><h1>'+respuesta["titulo"]+'</h1><p>'+respuesta["descripcion"]+'</p></div><hr>');

					swal({
						title: "¡OK!",
						text: "¡La imagen se subió correctamente!",
						type: "success",
						confirmButtonText: "Cerrar",
						closeOnConfirm: false
						},
						function(isConfirm){
							if (isConfirm){
								window.location = "galeria";
							}
						});

				}

			}

		});

	}

})
/*=====  Soltar Imagen  ======*/

/*=============================================
Eliminar Item Slide
=============================================*/

$(".eliminarGaleria").click(function(){

	if($(".eliminarGaleria").length == 1){

		$("#columnasGaleria").css({"height":"100px"});

	}

	idGalery = $(this).parent().attr("id");
	rutaGalery = $(this).attr("ruta");

	$(this).parent().remove();
	$("#item"+idGalery).remove();

	var borrarItem = new FormData();

	borrarItem.append("idGalery", idGalery);
	borrarItem.append("rutaGalery", rutaGalery);

	$.ajax({
		url:"views/ajax/gestorGaleria.php",
		method: "POST",
		data: borrarItem,
		cache: false,
		contentType: false,
		processData: false,
		success: function(respuesta){

		}

	})

})


/*=====  Eliminar Item Slide  ======*/

/*=============================================
Editar Item Slide
=============================================*/

$(".editarGalery").click(function(){

	idGalery = $(this).parent().attr("id");
	rutaImagen = $(this).parent().children("img").attr("src");
	rutaTitulo = $(this).parent().children("h1").html();
	rutaDescripcion = $(this).parent().children("p").html();
	
	$(this).parent().html('<img src="'+rutaImagen+'" class="img-thumbnail" style="margin-bottom:10px "><input type="text" class="form-control" id="enviarTitulo" placeholder="Título" value="'+rutaTitulo+'" style="margin-bottom:10px "><textarea row="5" id="enviarDescripcion" class="form-control" placeholder="Descripción" style="margin-bottom:10px ">'+rutaDescripcion+'</textarea><button class="btn btn-info pull-right" id="guardar'+idGalery+'" style="margin:10px">Guardar</button>');

	$("#guardar"+idGalery).click(function(){

		enviarId = idGalery.slice(4);

		enviarTitulo = $("#enviarTitulo").val();
		enviarDescripcion = $("#enviarDescripcion").val();

		var actualizarSlide = new FormData();

		actualizarSlide.append("enviarId",enviarId);
		actualizarSlide.append("enviarTitulo",enviarTitulo);
		actualizarSlide.append("enviarDescripcion",enviarDescripcion);

		$.ajax({
			url:"views/ajax/gestorGaleria.php",
			method: "POST",
			data: actualizarSlide,
			cache: false,
			contentType: false,
			processData: false,
			dataType:"json",
			success: function(respuesta){
				
				$("#guardar"+idGalery).parent().html('<span class="fa fa-pencil editarSlide" style="background:blue"></span><img src="'+rutaImagen+'" style="float:left; margin-bottom:10px" width="80%"><h1>'+respuesta["titulo"]+'</h1><p>'+respuesta["descripcion"]+'</p>');

				swal({
						title: "¡OK!",
						text: "¡Se han guardado los cambios correctamente!",
						type: "success",
						confirmButtonText: "Cerrar",
						closeOnConfirm: false
						},
						function(isConfirm){
							if (isConfirm){
								window.location = "galeria";
							}
						});

			}

		});



	})

})

/*=====  Editar  Item Slide  ======*/

/*=============================================
Ordenar Item Slide
=============================================*/

// var almacenarOrdenId = new Array();
// var ordenItem = new Array();

// $("#ordenarSlide").click(function(){

// 	$("#ordenarSlide").hide();
// 	$("#guardarSlide").show();

// 	$("#columnasGaleria").css({"cursor":"move"})
// 	$("#columnasGaleria span").hide()

// 	$("#columnasGaleria").sortable({
// 		revert: true,
// 		connectWith: ".bloqueSlide",
// 		handle: ".handleImg",
// 		stop: function(event){

// 			for(var i= 0; i < $("#columnasGaleria li").length; i++){

// 				almacenarOrdenId[i] = event.target.children[i].id;
// 				ordenItem[i]  =  i+1;  			

// 			}

// 		}

// 	});

// });

// $("#guardarSlide").click(function(){

// 	$("#ordenarSlide").show();
// 	$("#guardarSlide").hide();

// 	for(var i= 0; i < $("#columnasGaleria li").length; i++){

// 		var actualizarOrden = new FormData();
// 		actualizarOrden.append("actualizarOrdenSlide", almacenarOrdenId[i]);
// 		actualizarOrden.append("actualizarOrdenItem", ordenItem[i]);

// 		$.ajax({

// 			url:"views/ajax/gestorSlide.php",
// 			method: "POST",
// 			data: actualizarOrden,
// 			cache: false,
// 			contentType: false,
// 			processData: false,
// 			success: function(respuesta){
				
// 				$("#textoSlide ul").html(respuesta);

// 				swal({
// 						title: "¡OK!",
// 						text: "¡El orden se ha actualizado correctamente!",
// 						type: "success",
// 						confirmButtonText: "Cerrar",
// 						closeOnConfirm: false
// 						},
// 						function(isConfirm){
// 							if (isConfirm){
// 								window.location = "slide";
// 							}
// 						});



// 			}

// 		})

// 	}

// })

/*=====  Ordenar Item Slide  ======*/





