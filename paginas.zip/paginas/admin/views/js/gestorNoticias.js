/*=============================================
Agregar artículo          
=============================================*/

/*=============================================
Subir Imagen a través del Input         
=============================================*/
$("#subirFoto").change(function(){

	imagen = this.files[0];

	//Validar tamaño de la imagen

	imagenSize = imagen.size;

	if(Number(imagenSize) > 2000000){

		$("#arrastreImagenNoticia").before('<div class="alert alert-warning alerta text-center">El archivo excede el peso permitido, 200kb</div>')

	}

	else{

		$(".alerta").remove();

	}

	// Validar tipo de la imagen

	imagenType = imagen.type;

	if(imagenType == "image/jpeg" || imagenType == "image/png"){

		$(".alerta").remove();
	}

	else{

		$("#arrastreImagenNoticia").before('<div class="alert alert-warning alerta text-center">El archivo debe ser formato JPG o PNG</div>')

	}

	/*=============================================
	Mostrar imagen con AJAX       
	=============================================*/
	if(Number(imagenSize) < 2000000 && imagenType == "image/jpeg" || imagenType == "image/png"){

		var datos = new FormData();

		datos.append("imagen", imagen);

		$.ajax({
			url:"views/ajax/gestorNoticias.php",
			method: "POST",
			data: datos,
			cache: false,
			contentType: false,
			processData: false,
			beforeSend: function(){

					$("#arrastreImagenNoticia").before('<img src="views/images/status.gif" id="status">');

				},
			success: function(respuesta){
				
					$("#status").remove();

					if(respuesta == 0){

						$("#arrastreImagenNoticia").before('<div class="alert alert-warning alerta text-center">La imagen es inferior a 800px * 400px</div>')

					}else{

						$("#arrastreImagenNoticia").html('<div id="imagenArticulo"><img src="'+respuesta.slice(6)+'" class="img-thumbnail" width="250px" style="margin-bottom: 10px;"></div>');

					}

			}

		})

	}

})

/*=============================================
Editar Artículo        
=============================================*/

$(".editarNoticia").click(function(){

	idNoticia = $(this).parent().parent().attr("id");
	rutaImagen = $("#"+idNoticia).children("img").attr("src");
	titulo = $("#"+idNoticia).children("h1").html();
	subtitulo = $("#"+idNoticia).children("p").html();
	contenido = $("#"+idNoticia).children("p").html();

	$("#"+idNoticia).html('<form method="post" enctype="multipart/form-data"><div id="editarImagen"><input style="display:none" type="file" id="subirNuevaFoto" class="btn btn-default" style="margin-bottom: 10px;"><div id="nuevaFoto"><span class="fa fa-times btn btn-danger cambiarImagen pull-right">Cambiar Imagen</span><img src="'+rutaImagen+'" class="img-thumbnail" style="margin-bottom: 10px;"></div></div><input type="text" value="'+titulo+'" name="editarTitulo" class="form-control" style="margin-bottom: 10px;"><textarea cols="30" rows="1" name="editarSubtitulo" class="form-control" style="margin-bottom: 10px;">'+subtitulo+'</textarea><textarea name="editarContenido" id="editarContenido" cols="30" rows="5" class="form-control" style="margin-bottom: 10px;">'+contenido+'</textarea><input type="hidden" value="'+idNoticia+'" name="id"><input type="hidden" value="'+rutaImagen+'" name="fotoAntigua"><span><input type="submit" class="btn btn-primary pull-right" value="Guardar"></span><hr></form>');

	$(".cambiarImagen").click(function(){
	
		$(this).hide();

		$("#subirNuevaFoto").show();
		$("#subirNuevaFoto").css({"width":"90%"});
		$("#nuevaFoto").html("");
		$("#subirNuevaFoto").attr("name","editarImagen");
		$("#subirNuevaFoto").attr("required",true);

		$("#subirNuevaFoto").change(function(){

			imagen = this.files[0];
			imagenSize = imagen.size;

			if(Number(imagenSize) > 2000000){

				$("#editarImagen").before('<div class="alert alert-warning alerta text-center">El archivo excede el peso permitido, 200kb</div>')

			}

			else{

				$(".alerta").remove();

			}

			imagenType = imagen.type;
			
			if(imagenType == "image/jpeg" || imagenType == "image/png"){

				$(".alerta").remove();

			}

			else{

				$("#editarImagen").before('<div class="alert alert-warning alerta text-center">El archivo debe ser formato JPG o PNG</div>')

			}

			if(Number(imagenSize) < 2000000 && imagenType == "image/jpeg" || imagenType == "image/png"){

				var datos = new FormData();

				datos.append("imagen", imagen);	

				$.ajax({
						url:"views/ajax/gestorNoticias.php",
						method: "POST",
						data: datos,
						cache: false,
						contentType: false,
						processData: false,
						beforeSend: function(){

							$("#nuevaFoto").html('<img src="views/images/load.gif" style="width:15%" id="status2">');

						},
						success: function(respuesta){
				
							$("#status2").remove();

							if(respuesta == 0){

								$("#editarImagen").before('<div class="alert alert-warning alerta text-center">La imagen es inferior a 800px * 400px</div>')
							
							}

							else{

								$("#nuevaFoto").html('<img src="'+respuesta.slice(6)+'" class="img-thumbnail" style="margin-bottom: 10px;">');

							}
							
						}

				})	

			}

		})

	})

})

