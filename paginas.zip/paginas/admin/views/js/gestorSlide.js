/*=============================================
Agregar artículo          
=============================================*/

/*=============================================
Subir Imagen a través del Input         
=============================================*/
$("#subirFoto").change(function(){

	imagen = this.files[0];

	//Validar tamaño de la imagen

	imagenSize = imagen.size;

	if(Number(imagenSize) > 2000000){

		$("#arrastreImagenSlide").before('<div class="alert alert-warning alerta text-center">El archivo excede el peso permitido, 200kb</div>')
	}

	else{

		$(".alerta").remove();

	}

	// Validar tipo de la imagen

	imagenType = imagen.type;

	if(imagenType == "image/jpeg" || imagenType == "image/png"){

		$(".alerta").remove();
	}

	else{

		$("#arrastreImagenSlide").before('<div class="alert alert-warning alerta text-center">El archivo debe ser formato JPG o PNG</div>')

	}

	/*=============================================
	Mostrar imagen con AJAX       
	=============================================*/
	if(Number(imagenSize) < 2000000 && imagenType == "image/jpeg" || imagenType == "image/png"){

		var datos = new FormData();

		datos.append("imagen", imagen);

		$.ajax({
			url:"views/ajax/gestorSlide.php",
			method: "POST",
			data: datos,
			cache: false,
			contentType: false,
			processData: false,
			beforeSend: function(){
					$("#arrastreImagenSlide").before('<img src="views/images/status.gif" id="status">');
				},
			success: function(respuesta){
				
					$("#status").remove();

					if(respuesta == 0){

						$("#arrastreImagenSlide").before('<div class="alert alert-warning alerta text-center">La imagen es inferior a 800px * 400px</div>')

					}else{

						$("#arrastreImagenSlide").html('<div class="panel-body" id="imagenSlide" ><img src="'+respuesta.slice(6)+'" class="img-thumbnail" width="280px"></div>');

					}

			}

		})

	}

})

/*=============================================
Editar Artículo        
=============================================*/

$(".editarSlide").click(function(){

	idSlide =   $(this).parent().parent().attr("id");
	rutaImagen =   $("#"+idSlide).children("img").attr("src");
	titulo =       $("#"+idSlide).children("h1").html();

	$("#"+idSlide).html('<form method="post" enctype="multipart/form-data"><div id="editarImagen"><input style="display:none" type="file" id="subirNuevaFoto" class="btn btn-default"><div id="nuevaFoto" class="form-group"><span class="fa fa-times btn btn-danger cambiarImagen pull-right">cambiar Imagen</span><img src="'+rutaImagen+'" class="img-thumbnail"></div></div><div class="form-group"><input type="text" value="'+titulo+'" name="editarTitulo" class="form-control"></div><input type="hidden" value="'+idSlide+'" name="id"><input type="hidden" value="'+rutaImagen+'" name="fotoAntigua"><hr><span><input type="submit" class="btn btn-primary " value="Guardar"></span></form>');


	$(".cambiarImagen").click(function(){	
		$(this).hide();
		$("#subirNuevaFoto").show();
		$("#subirNuevaFoto").css({"width":"90%"});
		$("#nuevaFoto").html("");
		$("#subirNuevaFoto").attr("name","editarImagen");
		$("#subirNuevaFoto").attr("required",true);

		$("#subirNuevaFoto").change(function(){
			imagen = this.files[0];
			imagenSize = imagen.size;

			if(Number(imagenSize) > 2000000){
				$("#editarImagen").before('<div class="alert alert-warning alerta text-center">El archivo excede el peso permitido, 200kb</div>')
			}
			else{
				$(".alerta").remove();
			}

			imagenType = imagen.type;
			
			if(imagenType == "image/jpeg" || imagenType == "image/png"){
				$(".alerta").remove();
			}
			else{
				$("#editarImagen").before('<div class="alert alert-warning alerta text-center">El archivo debe ser formato JPG o PNG</div>')
			}

			if(Number(imagenSize) < 2000000 && imagenType == "image/jpeg" || imagenType == "image/png"){
				var datos = new FormData();
				datos.append("imagen", imagen);	
				$.ajax({
						url:"views/ajax/gestorSlide.php",
						method: "POST",
						data: datos,
						cache: false,
						contentType: false,
						processData: false,
						beforeSend: function(){

							$("#nuevaFoto").html('<img src="views/images/status.gif" style="width:15%" id="status2">');

						},
						success: function(respuesta){
				
							$("#status2").remove();
							if(respuesta == 0){
								$("#editarImagen").before('<div class="alert alert-warning alerta text-center">La imagen es inferior a 800px * 400px</div>')	
							}
							else{
								$("#nuevaFoto").html('<img src="'+respuesta.slice(6)+'" class="img-thumbnail">');
							}							
						}
				})	
			}
		})
	})
})

/*=============================================
Ordenar Item Artículos
=============================================*/

// var almacenarOrdenId = new Array();
// var ordenItem = new Array();

// $("#ordenarArticulos").click(function(){

// 	$("#ordenarArticulos").hide();
// 	$("#guardarOrdenArticulos").show();

// 	$("#editarArticulo").css({"cursor":"move"})
// 	$("#editarArticulo span i").hide()
// 	$("#editarArticulo button").hide()
// 	$("#editarArticulo img").hide()
// 	$("#editarArticulo p").hide()
// 	$("#editarArticulo hr").hide()
// 	$("#editarArticulo div").remove()
// 	$(".bloqueArticulo h1").css({"font-size":"14px","position":"absolute","padding":"10px", "top":"-15px"})
// 	$(".bloqueArticulo").css({"padding":"2px"})
// 	$("#editarArticulo span").html('<i class="glyphicon glyphicon-move" style="padding:8px"></i>')

// 	$("body, html").animate({

// 		scrollTop:$("body").offset().top

// 	}, 500)

// 	$("#editarArticulo").sortable({
// 		revert: true,
// 		connectWith: ".bloqueArticulo",
// 		handle: ".handleArticle",
// 		stop: function(event){

// 			for(var i= 0; i < $("#editarArticulo li").length; i++){
// 				almacenarOrdenId[i] = event.target.children[i].id;
// 				ordenItem[i]  =  i+1;
// 			}	
// 		}
// 	})

// 	$("#guardarOrdenArticulos").click(function(){
// 		$("#ordenarArticulos").show();
// 		$("#guardarOrdenArticulos").hide();

// 		for(var i= 0; i < $("#editarArticulo li").length; i++){
// 			var actualizarOrden = new FormData();
// 			actualizarOrden.append("actualizarOrdenArticulos", almacenarOrdenId[i]);
// 			actualizarOrden.append("actualizarOrdenItem", ordenItem[i]);

// 			$.ajax({
// 				url:"views/ajax/gestorArticulos.php",
// 				method: "POST",
// 				data: actualizarOrden,
// 				cache: false,
// 				contentType: false,
// 				processData: false,
// 				success: function(respuesta){

// 					$("#editarArticulo").html(respuesta);

// 					swal({
// 						title: "¡OK!",
// 						text: "¡El orden se ha actualizado correctamente!",
// 						type: "success",
// 						confirmButtonText: "Cerrar",
// 						closeOnConfirm: false
// 						},
// 						function(isConfirm){
// 							if (isConfirm){
// 								window.location = "articulos";
// 							}
// 						});


// 				}

// 			})


			
// 		}
	
// 	})

// })