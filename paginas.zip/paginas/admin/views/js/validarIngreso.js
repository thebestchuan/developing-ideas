function validarIngreso(){

	var expresion = /^[a-zA-Z0-9]*$/;

	if(!expresion.test($("#usuarioIngreso").val())){

		return false;
	}

	if(!expresion.test($("#passwordIngreso").val())){

		return false;
	}

	return true;

}


$("p#member span").click(function(){
	$("#cabezote #admin").slideToggle("fast")
	$("p#member span").toggleClass("fa-chevron-down");
	$("p#member span").toggleClass("fa-chevron-up");
})

/*=====  Fin de BOTONES ADMINISTRADOR  ======*/
