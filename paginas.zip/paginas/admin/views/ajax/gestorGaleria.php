<?php

require_once "../../models/gestorGaleria.php";
require_once "../../controllers/gestorGaleria.php";

#CLASE Y MÉTODOS
#-------------------------------------------------------------

class Ajax{

	#SUBIR LA IMAGEN DEL SLIDE
	#----------------------------------------------------------

	public $nombreImagen;
	public $imagenTemporal;

	public function gestorGaleriaAjax(){

		$datos = array("nombreImagen"=>$this->nombreImagen,
			           "imagenTemporal"=>$this->imagenTemporal);

		$respuesta = GestorGalery::mostrarImageController($datos);

		echo $respuesta;

	}

	#ELIMINAR ITEM SLIDE
	#----------------------------------------------------------
	public $idGalery;
	public $rutaGalery;
	public function eliminarGaleryAjax(){

		$datos = array("idGalery" => $this->idGalery, 
			           "rutaGalery" => $this->rutaGalery);

		$respuesta = GestorGalery::eliminarGaleryController($datos);

		echo $respuesta;

	}

	#ACTUALIZAR ITEM SLIDE
	#----------------------------------------------------------
	public $enviarId;
	public $enviarTitulo;
	public $enviarDescripcion;

	public function actualizarGaleryAjax(){

		$datos = array("enviarId" => $this->enviarId, 
			           "enviarTitulo" => $this->enviarTitulo,
			           "enviarDescripcion" => $this->enviarDescripcion);

		$respuesta = GestorGalery::actualizarGaleryController($datos);

		echo $respuesta;

	}

	#ACTUALIZAR ORDEN
	#---------------------------------------------
	
	// public $actualizarOrdenSlide;
	// public $actualizarOrdenItem;

	// public function actualizarOrdenAjax(){

	// 	$datos = array("ordenSlide" => $this->actualizarOrdenSlide,
	// 		           "ordenItem" => $this->actualizarOrdenItem);

	// 	$respuesta = GestorSlide::actualizarOrdenController($datos);

	// 	echo $respuesta;

	// }

}

#OBJETOS
#-----------------------------------------------------------
if(isset($_FILES["imagen"]["name"])){

	$a = new Ajax();
	$a -> nombreImagen = $_FILES["imagen"]["name"];
	$a -> imagenTemporal = $_FILES["imagen"]["tmp_name"];
	$a -> gestorGaleriaAjax();

}

if(isset($_POST["idGalery"])){

	$b = new Ajax();
	$b -> idGalery = $_POST["idGalery"];
	$b -> rutaGalery = $_POST["rutaGalery"];
	$b -> eliminarGaleryAjax();	

}

if(isset($_POST["enviarId"])){

	$c = new Ajax();
	$c -> enviarId = $_POST["enviarId"];
	$c -> enviarTitulo = $_POST["enviarTitulo"];
	$c -> enviarDescripcion = $_POST["enviarDescripcion"];
	$c -> actualizarGaleryAjax();	

}

if(isset($_POST["actualizarOrdenSlide"])){

	$d = new Ajax();
	$d -> actualizarOrdenSlide = $_POST["actualizarOrdenSlide"];
	$d -> actualizarOrdenItem = $_POST["actualizarOrdenItem"];
	$d -> actualizarOrdenAjax();

}
