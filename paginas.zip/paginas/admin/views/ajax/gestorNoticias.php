<?php

require_once "../../controllers/gestorNoticias.php";
require_once "../../models/gestorNoticias.php";


#CLASE Y MÉTODOS
#-------------------------------------------------------------
class Ajax{

	#SUBIR LA IMAGEN DEL ARTICULO
	#----------------------------------------------------------
	
	public $imagenTemporal;

	public function gestorNoticiasAjax(){

		$datos = $this->imagenTemporal;

		$respuesta = gestorNoticias::mostrarImagenController($datos);

		echo $respuesta;

	}

}

#OBJETOS
#-----------------------------------------------------------

if(isset($_FILES["imagen"]["tmp_name"])){

	$a = new Ajax();
	$a -> imagenTemporal = $_FILES["imagen"]["tmp_name"];
	$a -> gestorNoticiasAjax();

}