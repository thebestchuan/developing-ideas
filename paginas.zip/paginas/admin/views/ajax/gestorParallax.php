<?php

require_once "../../controllers/gestorParallax.php";
require_once "../../models/gestorParallax.php";


#CLASE Y MÉTODOS
#-------------------------------------------------------------
class Ajax{

	#SUBIR LA IMAGEN DEL Slide
	#----------------------------------------------------------
	
	public $imagenTemporal;

	public function gestorParallaxAjax(){

		$datos = $this->imagenTemporal;

		$respuesta = GestorParallax::mostrarImagenController($datos);

		echo $respuesta;

	}

	#ACTUALIZAR ORDEN
	#---------------------------------------------
	// public $actualizarOrdenArticulos;
	// public $actualizarOrdenItem;

	// public function actualizarOrdenAjax(){	

	// 	$datos = array("ordenArticulos" => $this->actualizarOrdenArticulos,
	// 		           "ordenItem" => $this->actualizarOrdenItem);

	// 	$respuesta = GestorArticulos::actualizarOrdenController($datos);

	// 	echo $respuesta;

	// }

}

#OBJETOS
#-----------------------------------------------------------

if(isset($_FILES["imagen"]["tmp_name"])){

	$a = new Ajax();
	$a -> imagenTemporal = $_FILES["imagen"]["tmp_name"];
	$a -> gestorParallaxAjax();

}

// if(isset($_POST["actualizarOrdenArticulos"])){

// 	$b = new Ajax();
// 	$b -> actualizarOrdenArticulos = $_POST["actualizarOrdenArticulos"];
// 	$b -> actualizarOrdenItem = $_POST["actualizarOrdenItem"];
// 	$b -> actualizarOrdenAjax();

// }