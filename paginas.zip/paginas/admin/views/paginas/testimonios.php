<?php
session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
 include "menu.php";
 ?>
<div>Testimonios</div>	