<?php
session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
 include "menu.php";
 ?>

<div  class="col-lg-9 col-md-9 col-sm-9 col-xs-9">
 
 <div>

	<table id="tablaSuscriptores" class="table table-border">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Email</th>
        <th>Acciones</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
  
      <?php

      $suscriptores = new SuscriptoresController();
      $suscriptores -> mostrarSuscriptoresController();
      $suscriptores -> borrarSuscriptoresController();

      ?>

    </tbody>
  </table>
  </div>

</div>
<!--====  Fin de SUSCRIPTORES  ====-->