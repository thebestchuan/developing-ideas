<?php
session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
 include "menu.php";
 ?> 

 <div id="seccionSlide" class="col-md-9">
	<div><a href="#nuevoSlide" data-toggle="modal">
	<button class="btn btn-primary">Nuevo Slide</button>
	</a></div>	
<div id="nuevoSlide" style="padding: 10px; " class="modal fade">		
	<div class="modal-dialog modal-content" style="padding: 15px">
		<div class="modal-header" style="border:1px solid #eee; margin-bottom: 10px;">	        
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			 <h3 class="modal-title">Subir Nueva Imagen</h3>        
		</div>
	<form method="post" enctype="multipart/form-data">

			<input name="tituloSlide" type="text" placeholder="Título Slide" class="form-control" style="margin-bottom: 10px;" required>

			<input type="file" name="imagen" class="btn btn-default" id="subirFoto" style="margin-bottom: 10px;" required>

			<p>Tamaño recomendado: 800px * 400px, peso máximo 2MB</p>

			<div id="arrastreImagenArticulo" style="text-align: center; border: dashed; margin-bottom: 10px;">	
				
			</div>

			<input type="submit" id="guardarArticulo" value="Guardar" class="btn btn-primary">

		</form>
	</div>
	</div>	

				<?php 
					$crearSlide= new GestorSlide();		
					$crearSlide->guardarSlideController();
				 ?>
	<div id="editarSlide" style="padding: 10px;">
		
		<?php 
		$mostrarSlide = new GestorSlide();	
		$mostrarSlide->mostrarSlideController();
		$mostrarSlide->borrarSlideController();
		$mostrarSlide->editarSlideController();
		 ?>

</div>
</div>







