<?php
session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
include "menu.php";
 ?>

 
<div id="seccionArticulo" class="col-md-9">
	<div><a href="#nuevoArticulo" data-toggle="modal">
	<button class="btn btn-primary">Nuevo Artículo</button>
	</a></div>	

<div id="nuevoArticulo" style="padding: 10px; " class="modal fade">		
	<div class="modal-dialog modal-content" style="padding: 15px">
		<div class="modal-header" style="border:1px solid #eee; margin-bottom: 10px;">	        
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			 <h3 class="modal-title">Crear Nuevo Artículo</h3>        
		</div>
	<form method="post" enctype="multipart/form-data">

			<input name="tituloCulture" type="text" placeholder="Título" class="form-control" style="margin-bottom: 10px;" required>

			<textarea name="subtituloCulture" id="" cols="30" rows="2" placeholder="Sub-titulo" class="form-control"  maxlength="170" style="margin-bottom: 10px;" required></textarea>

			<textarea name="subtituloCulture1" id="" cols="30" rows="2" placeholder="Sub-titulo 1" class="form-control"  maxlength="170" style="margin-bottom: 10px;" required></textarea>

			<input type="file" name="imagen" class="btn btn-default" id="subirFoto" style="margin-bottom: 10px;" required>

			<p>Tamaño recomendado: 800px * 400px, peso máximo 2MB</p>

			<div id="arrastreImagenCulture" style="text-align: center; border: dashed; margin-bottom: 10px;">	
				
			</div>

			<textarea name="contenidoCulture" id="" cols="30" rows="10" placeholder="Contenido" class="form-control" style="margin-bottom: 10px;" required></textarea>

			<input type="submit" id="guardarArticulo" value="Guardar" class="btn btn-primary">

		</form>
	</div>
	</div>
	<?php

		 $crearCulture = new GestorCulture();
		 $crearCulture -> guardarCultureController();

	?>


<div id="editarArticulo" style="padding: 10px;">
	<?php

		$mostrarCulture = new GestorCulture();
		$mostrarCulture -> mostrarCultureController();
		$mostrarCulture -> borrarCultureController();
		$mostrarCulture -> editarCultureController();

	?>

</div>
 
</div>
