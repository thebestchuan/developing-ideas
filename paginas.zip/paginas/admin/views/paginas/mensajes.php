<?php
session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
 include "menu.php";
 ?>
<div id="bandejaMensajes" class="col-md-4 ">
 
	 <div >
	    <h1>Bandeja de Entrada</h1>
	    <hr>
	 </div>

	  <?php

	 	$mostrarMensajes = new MensajesController();
	 	$mostrarMensajes -> mostrarMensajesController();
	 	$mostrarMensajes -> borrarMensajesController();

	 ?>

</div>

  <div class="col-md-5" id="lecturaMensajes">		
		
 
	 <div >
	  <hr>
	   <button id="enviarCorreoMasivo"  class="btn btn-success">Enviar mensaje a todos los usuarios</button>
	    <hr>
	 </div>

	 <div id="visorMensajes">

	 <?php

	 	$responderMensajes = new MensajesController();
	 	$responderMensajes -> responderMensajesController();
	 	$responderMensajes -> mensajesMasivosController();

	 ?>


	 </div>


</div>


<script>

</script>

 
 