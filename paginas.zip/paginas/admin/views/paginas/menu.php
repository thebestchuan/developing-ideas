 <div class="col-md-3">
        <div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <li class="submenu">
                         <a href="inicio">
                            <i class="glyphicon glyphicon-list"></i> Idex Principal
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul> 
                            <li><a href="galeria">Galeria</a></li>                           
                            <li><a href="slide">Slide</a></li>
                             <li><a href="parallax">Parallax</a></li>
                            <li><a href="mensajes">Mensajes</a></li>
                            <li><a href="suscriptores">Suscriptores</a></li>
                            <li><a href="culture">Acerca de</a></li>
                            <li><a href="articulos">Articulos</a></li>
                            <li><a href="noticias">Noticias</a></li>
                            <li><a href="testimonios">Testimonios</a></li>
                            
                        </ul>
                    </li>
                    </li>
                </ul>
             </div>
      </div>
