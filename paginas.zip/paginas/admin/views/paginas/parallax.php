<?php
session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
 include "menu.php";
 ?> 

 <div class="col-md-9">
  <div style="padding: 20px;" class="row"> 
				<!--==== AGREGAR Slide  ====-->
				<div id="agregarSlide" class="col-md-7" style="background: green; border: dashed;">
					<div style="padding: 15px">
				
					<form method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
					<div class="form-group">
					<input type="text" name="tituloParallax" placeholder="Título de Slide" class="form-control" required>
					</div>
					<div class="form-group">
					<input type="file" name="imagen" class="btn btn-default" id="subirFoto" required >
					</div>
					<p>Tamaño recomendado: 800px * 400px, peso máximo 2MB</p>

					<div class="col-md-12" id="arrastreImagenParallax">

					</div>
					
					<input type="submit" id="guardarSlide" value="Guardar Slide" class="btn btn-primary">
				</form>
				</div>
				</div>	

				<?php 
					$crearSlide= new GestorParallax();		
					$crearSlide->guardarParallaxController();
				 ?>
	</div>
	<div class="row" id="editarSlide">
		
		<?php 
		$mostrarSlide = new GestorParallax();	
		$mostrarSlide->mostrarParallaxController();
		$mostrarSlide->borrarParallaxController();
		$mostrarSlide->editarParallaxController();
		 ?>

</div>
</div>







