<?php
session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
include "menu.php";
 ?>

 
<div id="seccionArticulo" class="col-md-9">
	<div><a href="#nuevoArticulo" data-toggle="modal">
	<button class="btn btn-primary">Nuevo Artículo</button>
	</a></div>	

<div id="nuevoArticulo" style="padding: 10px; " class="modal fade">		
	<div class="modal-dialog modal-content" style="padding: 15px">
		<div class="modal-header" style="border:1px solid #eee; margin-bottom: 10px;">	        
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			 <h3 class="modal-title">Crear Nuevo Artículo</h3>        
		</div>
	<form method="post" enctype="multipart/form-data">

			<input name="tituloArticulo" type="text" placeholder="Título del Artículo" class="form-control" style="margin-bottom: 10px;" required>

			<textarea name="introArticulo" id="" cols="30" rows="5" placeholder="Introducción del Articulo" class="form-control"  maxlength="170" style="margin-bottom: 10px;" required></textarea>

			<input type="file" name="imagen" class="btn btn-default" id="subirFoto" style="margin-bottom: 10px;" required>

			<p>Tamaño recomendado: 800px * 400px, peso máximo 2MB</p>

			<div id="arrastreImagenArticulo" style="text-align: center; border: dashed; margin-bottom: 10px;">	
				
			</div>

			<textarea name="contenidoArticulo" id="" cols="30" rows="10" placeholder="Contenido del Articulo" class="form-control" style="margin-bottom: 10px;" required></textarea>

			<input type="submit" id="guardarArticulo" value="Guardar Artículo" class="btn btn-primary">

		</form>
	</div>
	</div>
	<?php

		$crearArticulo = new GestorArticulos();
		$crearArticulo -> guardarArticuloController();

	?>


<div id="editarArticulo" style="padding: 10px;">
	<?php

		$mostrarArticulo = new GestorArticulos();
		$mostrarArticulo -> mostrarArticulosController();
		$mostrarArticulo -> borrarArticuloController();
		$mostrarArticulo -> editarArticuloController();

	?>

</div>
 
</div>




