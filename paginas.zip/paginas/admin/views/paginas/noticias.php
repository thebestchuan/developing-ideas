<?php
session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
include "menu.php";
 ?>

 
<div id="seccionArticulo" class="col-md-9">
	<div><a href="#nuevaNoticia" data-toggle="modal">
	<button class="btn btn-primary">Nuevo Noticia</button>
	</a></div>	

<div id="nuevaNoticia" style="padding: 10px; " class="modal fade">		
	<div class="modal-dialog modal-content" style="padding: 15px">
		<div class="modal-header" style="border:1px solid #eee; margin-bottom: 10px;">	        
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			 <h5 class="modal-title">Crear Nuevo Noticia</h5>        
		</div>
	<form method="post" enctype="multipart/form-data">

			<input name="tituloNoticia" type="text" placeholder="Título" class="form-control" style="margin-bottom: 10px;" required>

			<textarea name="subtituloNoticia" id="" cols="30" rows="3" placeholder="Sub Título" class="form-control" style="margin-bottom: 10px;" required></textarea>

			<input type="file" name="imagen" class="btn btn-default" id="subirFoto" style="margin-bottom: 10px;" required>

			<p style="text-align: center;">Tamaño recomendado: 970px * 970px, peso máximo 2MB</p>

			<div id="arrastreImagenNoticia" style="text-align: center; border: dashed; margin-bottom: 10px;">	
				
			</div>

			<textarea name="contenidoNoticia" id="" cols="30" rows="7" placeholder="Contenido" class="form-control" style="margin-bottom: 10px;" required></textarea>

			<input type="submit" id="guardarNoticia" value="Guardar Artículo" class="btn btn-primary">

		</form>
	</div>
	</div>
	<?php

		$crearNoticia = new gestorNoticias();
		$crearNoticia -> guardarNoticiaController();

	?>


<div id="editarArticulo" style="padding: 10px;">
	<?php

		$mostrarNoticia = new gestorNoticias();
		$mostrarNoticia -> mostrarNoticiasController();
		$mostrarNoticia -> borrarNoticiasController();
		$mostrarNoticia -> editarNoticiasController();

	?>

</div>
 
</div>



