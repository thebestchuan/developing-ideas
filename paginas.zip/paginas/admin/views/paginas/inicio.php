<?php

session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
 include "menu.php";
 ?>
<h1>Esto es el panel de administracion</h1>
