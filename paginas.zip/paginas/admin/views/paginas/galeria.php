<?php
session_start();

if(!$_SESSION["validar"]){

	header("location:ingreso");

	exit();

}

include "header.php";
 include "menu.php";
 ?>
<div class="col-md-9">
			<p style="text-align: center;"><span class="fa fa-arrow-down"></span><strong>Arrastra aquí tu imagen, tamaño recomendado: 970px * 647px</strong></p>

			<div class="col-md-12" style="border: dashed;" id="columnasGaleria">					
					
				<?php
				$slide = new GestorGalery();
				$slide -> mostrarImageVistaController();
				?>
			</div>

			<div id="textoGalery" class="col-md-12">
			
			<hr>
				
				<div id="ordenarTextGalery">
					
			<?php
				$slide = new GestorGalery();
				$slide -> editorGaleryController();
				?>		

				</div>
			</div>



</div>



