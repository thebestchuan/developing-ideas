<div class="header" style="background: blue;">
   <div class="container">
    <div class="row">
     <div class="col-md-12">  
     <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">

  <?php

  if($_SESSION["rol"] == 0){
    
    echo '<ul class="nav navbar-nav">
      <li  style="background: green; border-radius:100%; margin-right: 10px">
        <a href="mensajes" style="color: #fff">
            <i class="fa fa-envelope"></i>'; 
            
              $revisarMensajes = new MensajesController();
              $revisarMensajes -> mensajesSinRevisarController();
            
      echo '</a>
      </li>

      <li  style="background: green; border-radius:100%;  margin-right: 10px">
        <a href="suscriptores" style="color: #fff">
            <i class="fa fa-bell"></i>'; 
          

          $revisarSuscriptores = new SuscriptoresController();
          $revisarSuscriptores -> suscriptoresSinRevisarController(); 
            
      echo '</a>
      </li>
      
    </ul>';

  }

  ?>

  </div>
        <div id="time" class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
    
    <div class="text-center" style="padding: 15px; font-size: 20px">

    <?php

      switch(date("l")){
          case "Monday":
        $dia = "Lunes";   
        break;
        case "Tuesday":
        $dia = "Martes";    
        break;
        case "Wednesday":
        $dia = "Miércoles";
        break;
        case "Thursday":
        $dia = "Jueves";
        break;
        case "Friday":
        $dia = "Viernes";
        break;
        case "Saturday":
        $dia = "Sábado";
        break;
        case "Sunday":
        $dia = "Domingo";
        break;
      }

      switch(date("F")){
        case "January":
        $mes = "Enero";
        break;
        case "February":
        $mes = "Febrero";
        break;
        case "March":
        $mes = "Marzo";
        break;
        case "April":
        $mes = "Abril";
        break;
        case "May":
        $mes = "Mayo";
        break;
        case "June":
        $mes = "Junio";
        break;
        case "July":
        $mes = "Julio";
        break;
        case "August":
        $mes = "Agosto";
        break;
        case "September":
        $mes = "Septiembre";
        break;
        case "October":
        $mes = "Octubre";
        break;
        case "November":
        $mes = "Noviembre";
        break;
        case "December":
        $mes = "Diciembre";
        break;  
      }

      echo $dia.", ".date("d")." de ".$mes." de ".date("Y");
        
    ?>

    </div>

  </div>

      <div class="col-md-4"><div class="navbar navbar-inverse" role="banner">
        <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation" style="margin-bottom: 10px">
        <ul class="nav navbar-nav">
         <span class="pull-left">
          <img src="<?php echo $_SESSION["photo"];?>" class="img-circle" style="width:40px; height:40px; display:inline; margin:5px;">
        </span>
       <li class="dropdown">
          <a data-toggle="dropdown"><?php echo $_SESSION["usuario"];?><b class="caret"></b></a>
          <ul class="dropdown-menu animated fadeInUp">
           <li><a href="perfil"><span class="fa fa-user"></span>Editar Perfil</a></li>
          <li><a href="salir"><span class="fa fa-times"></span>Salir</a></li>
          </ul>
        </li>
        </ul>
        </nav>
      </div> </div>

      
     </div>
    </div>
   </div>
  </div>


