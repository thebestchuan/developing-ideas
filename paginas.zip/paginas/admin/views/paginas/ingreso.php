    <div class="container-login center-align">
        <div style="margin:15px 0;">
            <i class="zmdi zmdi-account-circle zmdi-hc-5x"></i>
            <p>Inicia sesión con tu cuenta</p>   
        </div>
        <form method="post" onsubmit="return validarIngreso()" >
            <div class="input-field">
                <input id="UserName" type="text" class="validate" name="usuarioIngreso">
                <label for="UserName"><i class="zmdi zmdi-account"></i>&nbsp; Nombre</label>
            </div>
            <div class="input-field col s12">
                <input id="Password" type="password" class="validate" name="usuarioPassword">
                <label for="Password"><i class="zmdi zmdi-lock"></i>&nbsp; Contraseña</label>
            </div>
                <?php

            $ingreso = new Ingreso();
            $ingreso -> ingresoController();
            
        ?>

        <input class="form-control formIngreso btn btn-primary" type="submit" value="Enviar">
        </form>
        <div class="divider" style="margin: 20px 0;"></div>
        <a href="home.html">Crear cuenta</a>
    </div>