<div class="page-content container">
    <div class="row">
      <div class="col-md-4 col-md-offset-4">
        <div class="login-wrapper">
              <div class="box">
                  <div class="content-wrap">
                      <h6>Panel de Ingreso</h6>
                      <form method="post" id="formIngreso" onsubmit="return validarIngreso()">
    <input class="form-control formIngreso" type="text" placeholder="Ingrese su Usuario" name="usuarioIngreso" id="usuarioIngreso" >
                      <input class="form-control" type="password" placeholder="Password" name="passwordIngreso" id="passwordIngreso">
                      <?php

            $ingreso = new Ingreso();
            $ingreso -> ingresoController();
            
        ?>

        <input class="form-control formIngreso btn btn-primary" type="submit" value="Enviar">
        </form>                                 
                  </div>
              </div>
          </div>
      </div>
    </div>
  </div>
