<!DOCTYPE html>
<html>
  <head>
    <title>ABCH |</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="views/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="views/css/styles.css" rel="stylesheet">
    <link rel="stylesheet" href="views/css/font-awesome.min.css">
    <link rel="stylesheet" href="views/css/fonts.css">  
    <link rel="stylesheet" href="views/css/sweetalert.css">
    <link rel="stylesheet" href="views/css/menu.css">

  
    <script src="views/js/sweetalert.min.js"></script>
  </head>
  <body >
    <div class="container" style="padding-top: 5px">
        <div class="row">
      <?php
      $modulos = new Enlaces();
      $modulos -> enlacesController();    
    ?>
      </div>
    </div>
		
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="views/js/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="views/bootstrap/js/bootstrap.min.js"></script>
    <script src="views/js/custom.js"></script>
    <script src="views/js/validarIngreso.js"></script>
    <script src="views/js/gestorSlide.js"></script>
    <script src="views/js/gestorParallax.js"></script>
    <script src="views/js/gestorPerfiles.js"></script>
    <script src="views/js/gestorArticulos.js"></script>
    <script src="views/js/gestorCulture.js"></script>
    <script src="views/js/gestorGaleria.js"></script>
    <script src="views/js/gestorNoticias.js"></script>
    <script src="views/js/gestorMensajes.js"></script>
    <script src="views/js/gestorPerfiles.js"></script>
    <script src="views/js/gestorSuscriptores.js"></script>
    <script src="views/js/gestorMensaje.js"></script>
  </body>
</html>