<?php 
class Noticias
{
	public function seleccionarNoticiasController(){
		$respuesta= NoticiasModels::seleccionarNoticiasModel("noticias");

		foreach ($respuesta as $row => $item) {
			echo '<div class="col-sm-4">
                    <!-- News -->
                    <article>
                        <img class="img-responsive" src="admin/'.$item["ruta"].'" alt="Image">
                        <div class="g-bg-color--white g-box-shadow__dark-lightest-v2 g-text-center--xs g-padding-x-40--xs g-padding-y-40--xs">
                            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2">'.$item["titulo"].'</p>
                            <h3 class="g-font-size-22--xs g-letter-spacing--1"><a href="http://keenthemes.com/">'.$item["subtitulo"].'</a></h3>
                            <p>'.$item["contenido"].'</p>
                        </div>
                    </article>
                    <!-- End News -->
                </div>';
		}
	}
}