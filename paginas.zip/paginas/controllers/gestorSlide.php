<?php 
class Slide
{
	public function seleccionarSlideController(){
		$respuesta= SlideModels::seleccionarSlideModel("slide");

		foreach ($respuesta as $row => $item) {
			echo '<div class="g-fullheight--xs g-bg-position--center swiper-slide" 
			style="background: url(admin/views/'.substr($item["ruta"],6).');">
                    <div class="container g-text-center--xs g-ver-center--xs">
                        <div class="g-margin-b-30--xs">
                            <div class="g-margin-b-30--xs">
                                <h2 class="g-font-size-35--xs g-font-size-45--sm g-font-size-55--md g-color--white">'.$item["titulo"].'</h2>
                            </div>
                            <a class="js__popup__youtube" href="https://www.youtube.com/watch?v=lcFYdgZKZxY" title="Intro Video">
                                <i class="s-icon s-icon--lg s-icon--white-bg g-radius--circle ti-control-play"></i>
                            </a>
                        </div>
                    </div>
                </div>';
		}
	}
}