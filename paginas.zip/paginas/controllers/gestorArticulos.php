<?php 
class Articulos
{
	public function seleccionarArticulosController(){
		$respuesta= ArticulosModels::seleccionarArticulosModel("articulos");

		foreach ($respuesta as $row => $item) {
			echo '<div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md"  style="padding: 15px;">
                    <div class="clearfix">
                        <div class="g-media g-width-30--xs">
                            <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".1s">
                                <img src="admin/'.$item["ruta"].'" width="30px">
                            </div>
                        </div>                              
                        <div class="g-media__body g-padding-x-20--xs">
                            <h3 class="g-font-size-18--xs">'.$item["titulo"].'</h3>
                            <p class="g-margin-b-0--xs">'.$item["introduccion"].'</p>
                            <a href="#articulo'.$item["id"].'" data-toggle="modal">
                            <button class="btn btn-default">Leer Más</button>
                            </a>
                        </div>
                    </div>
                </div>
                    <div id="articulo'.$item["id"].'" class="modal fade">

                        <div class="modal-dialog modal-content">
                            <div class="modal-header" style="border:1px solid #eee">                        
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h3 class="modal-title">'.$item["titulo"].'</h3>
                            </div>

                            <div class="modal-body" style="border:1px solid #eee">        
                                <img src="admin/'.$item["ruta"].'" width="100%" style="margin-bottom:20px">
                                <p class="parrafoContenido">'.$item["contenido"].'</p>        
                            </div>

                            <div class="modal-footer" style="border:1px solid #eee">        
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>        
                            </div>

                        </div>

                    </div>';
		}
	}
}