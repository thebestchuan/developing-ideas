<?php

class TemplateController{

	public function template(){

		include "views/tem_principal.php";

	}

}
