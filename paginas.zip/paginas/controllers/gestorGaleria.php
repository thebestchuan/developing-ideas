<?php 
class Galery
{
	public function seleccionarGaleryController(){
		$respuesta= GaleryModels::seleccionarGaleryModel("galeria");

		foreach ($respuesta as $row => $item) {
			echo '<div class="s-portfolio__item cbp-item motion graphic">
            <div class="s-portfolio__img-effect">
                <img src="admin/'.substr($item["ruta"], 6).'" alt="Portfolio Image">
            </div>
            <div class="s-portfolio__caption-hover--cc">
                <div class="g-margin-b-25--xs">
                    <h4 class="g-font-size-18--xs g-color--white g-margin-b-5--xs">'.$item["titulo"].'</h4>
                    <p class="g-color--white-opacity">'.$item["descripcion"].'</p>
                </div>
                <ul class="list-inline g-ul-li-lr-5--xs g-margin-b-0--xs">
                    <li>
                        <a href="admin/'.substr($item["ruta"], 6).'" class="cbp-lightbox s-icon s-icon--sm s-icon--white-bg g-radius--circle" data-title="'.$item["titulo"].'<br/>'.$item["descripcion"].'">
                            <i class="ti-fullscreen"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" class="s-icon s-icon--sm s-icon s-icon--white-bg g-radius--circle">
                            <i class="ti-link"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>';
		}
	}
}