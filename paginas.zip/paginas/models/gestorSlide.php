<?php

require_once "admin/models/conexion.php";

class SlideModels{

	public function seleccionarSlideModel($tabla){

		$stmt = Conexion::conectar()->prepare("SELECT titulo,ruta FROM $tabla");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

	}

}