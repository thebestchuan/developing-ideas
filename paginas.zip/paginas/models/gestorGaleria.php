<?php

require_once "admin/models/conexion.php";

class GaleryModels{

	public function seleccionarGaleryModel($tabla){

		$stmt = Conexion::conectar()->prepare("SELECT id,ruta,titulo,descripcion FROM $tabla");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

	}

}