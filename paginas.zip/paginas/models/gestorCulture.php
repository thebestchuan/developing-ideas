<?php

require_once "admin/models/conexion.php";

class CultureModels{

	public function seleccionarCultureModel($tabla){

		$stmt = Conexion::conectar()->prepare("SELECT id, titulo, ruta, subtitulo, subtitulo1, contenido FROM $tabla");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

	}

}