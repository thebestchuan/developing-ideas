<?php

require_once "admin/models/conexion.php";

class ParallaxModels{

	public function seleccionarParallaxModel($tabla){

		$stmt = Conexion::conectar()->prepare("SELECT id,titulo,ruta FROM $tabla");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

	}

}