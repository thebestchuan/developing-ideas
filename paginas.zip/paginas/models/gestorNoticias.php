<?php

require_once "admin/models/conexion.php";

class NoticiasModels{

	public function seleccionarNoticiasModel($tabla){

		$stmt = Conexion::conectar()->prepare("SELECT id,titulo,ruta,subtitulo,contenido FROM $tabla");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

	}

}