<?php

require_once "admin/models/conexion.php";

class ArticulosModels{

	public function seleccionarArticulosModel($tabla){

		$stmt = Conexion::conectar()->prepare("SELECT id,titulo,ruta,introduccion,contenido FROM $tabla");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

	}

}